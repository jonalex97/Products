﻿using ProductosWebAPI.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosWebAPI.Domain.Interfaces
{
    public interface IProductRepository
    {
        public Task<IEnumerable<ProductDto>> GetAllAsync();
        public Task<ProductDto?> GetByIdAsync(Guid id);
        public Task<Guid> AddAsync(ProductDto product);
        public Task<bool> UpdateAsync(ProductDto product);
        public Task<bool> DeleteAsync(Guid id);
    }
}
