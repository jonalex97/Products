﻿using ProductosWebAPI.Domain.Entities;

namespace ProductosWebAPI.Domain.Interfaces
{
    public interface IUsuarioRepository
    {
        Task<UsuarioDto?> ObtenerPorUsernameAsync(string usuario);
    }
}
