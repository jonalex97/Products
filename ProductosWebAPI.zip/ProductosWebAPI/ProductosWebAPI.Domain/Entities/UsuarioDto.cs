﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosWebAPI.Domain.Entities
{
    public class UsuarioDto
    {
        public Guid Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty; // En texto plano para simplificar
        public string Rol { get; set; } = "User";

    }
}
