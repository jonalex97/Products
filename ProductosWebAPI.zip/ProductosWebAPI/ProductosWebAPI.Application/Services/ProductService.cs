﻿using ProductosWebAPI.Application.Interfaces;
using ProductosWebAPI.Domain.Entities;
using ProductosWebAPI.Domain.Interfaces;
using ProductosWebAPI.Infrastructure.Persistence.Contexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosWebAPI.Application.Services
{
    public class ProductService(IProductRepository productRepository) : IProductService
    {
        private readonly IProductRepository _productRepository = productRepository;
        public async Task<Guid?> CreateProductAsync(ProductDto product)
        {
            Guid? id = await _productRepository.AddAsync(product);

            return id;
        }

        public async Task<bool> DeleteProductAsync(Guid id)
        {
            return await _productRepository.DeleteAsync(id);
        }

        public async Task<List<ProductDto>> GetListProductAsync()
        {
            List<ProductDto> products = new List<ProductDto>();
            var productList = await _productRepository.GetAllAsync();

            return productList.ToList();
        }

        public async Task<ProductDto?> GetProductByIdAsync(Guid id)
        {
            return await _productRepository.GetByIdAsync(id);
        }

        public async Task<bool?> UpdateProductAsync(ProductDto product)
        {
            var result = await _productRepository.UpdateAsync(product);

            return result;
        }
    }
}
