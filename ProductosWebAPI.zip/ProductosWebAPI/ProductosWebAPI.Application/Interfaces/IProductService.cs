﻿using ProductosWebAPI.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosWebAPI.Application.Interfaces
{
    public interface IProductService
    {
        public Task<List<ProductDto>> GetListProductAsync();
        public Task<ProductDto?> GetProductByIdAsync(Guid id);
        public Task<Guid?> CreateProductAsync(ProductDto product);
        public Task<bool?> UpdateProductAsync(ProductDto product);
        public Task<bool> DeleteProductAsync(Guid id);
    }
}
