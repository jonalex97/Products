﻿using ProductosWebAPI.Infrastructure.Persistence.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductosWebAPI.Application.DTO
{
    public class ProductHistorial
    {
        public Guid Id { get; set; }
        public Guid ProductoId { get; set; }
        public DateTime FechaCambio { get; set; }
        public string CampoModificado { get; set; } = null!;
        public string? ValorAnterior { get; set; }
        public string? ValorNuevo { get; set; }
        public string UsuarioModificador { get; set; } = null!;
    }
}
