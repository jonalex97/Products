﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductosWebAPI.Application.Interfaces;
using ProductosWebAPI.Application.Services;
using ProductosWebAPI.Domain.Entities;

namespace ProductosWebAPI.API.Controllers
{
    [Route("api/[controller]")]
    public class ProductController(IProductService productService) : Controller
    {
        private readonly IProductService _productService = productService;

        [Authorize]
        [HttpGet("AllProducts")]
        public async Task<IActionResult> ObtenerProductos()
        {
            var productos = await _productService.GetListProductAsync();
            
            if (productos.Count > 0)
                return BuildHttpResponse(200, productos);
            else
                return BuildHttpResponse(204, productos);
        }

        [Authorize]
        [HttpGet("ById/{id}")]
        public async Task<IActionResult> ObtenerProductoPorId(Guid id)
        {
            var producto = await _productService.GetProductByIdAsync(id);

            if (producto != null)
                return BuildHttpResponse(200, producto);
            else
                return BuildHttpResponse(404, $"Producto con ID {id} no encontrado.");
        }
        [Authorize]
        [HttpPost("New")]
        public async Task<IActionResult> CrearProducto([FromBody] ProductDto productDto)
        {
            if (productDto == null)
                return BuildHttpResponse(400, "El producto no puede ser nulo.");
            var productoCreado = await _productService.CreateProductAsync(productDto);
            if (productoCreado != null)
                return BuildHttpResponse(200, productoCreado);
            else
                return BuildHttpResponse(500, "Error al crear el producto.");
        }

        [Authorize]
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> ActualizarProducto(Guid id, [FromBody] ProductDto productDto)
        {
            if (productDto == null)
                return BuildHttpResponse(400, "El producto no puede ser nulo.");
            productDto.Id = id; // Aseguramos que el ID del producto a actualizar sea el correcto
            var productoActualizado = await _productService.UpdateProductAsync(productDto);
            if (productoActualizado != null)
                return BuildHttpResponse(200, productoActualizado);
            else
                return BuildHttpResponse(500, "Error al actualizar el producto.");
        }

        [Authorize]
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> EliminarProducto(Guid id)
        {
            var eliminado = await _productService.DeleteProductAsync(id);
            if (eliminado)
                return BuildHttpResponse(204, "Producto eliminado"); // No content
            else
                return BuildHttpResponse(404, $"Producto con ID {id} no encontrado.");
        }
        public static IActionResult BuildHttpResponse<T>(int code, T response)
        {
            return code switch
            {
                200 => new OkObjectResult(response),
                204 => new NoContentResult(), // Token expirado, monto incorrecto, etc.
                404 => new NotFoundObjectResult(response),            // Token no encontrado
                500 => new ObjectResult(response) { StatusCode = 500 }, // Error interno
                _ => new BadRequestObjectResult(response)           // Otros errores
            };
        }
    }
}
