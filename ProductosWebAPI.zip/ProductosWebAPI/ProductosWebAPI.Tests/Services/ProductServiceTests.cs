﻿using Moq;
using ProductosWebAPI.Application.Services;
using ProductosWebAPI.Domain.Entities;
using ProductosWebAPI.Domain.Interfaces;
using ProductosWebAPI.Infrastructure.Persistence.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ProductosWebAPI.Tests.Services
{
    public class ProductServiceTests
    {
        
        [Fact]
        public async Task CreateProductAsync_ShouldAddProductAndHistorial()
        {
            // Arrange
            var productoDto = new ProductDto { Nombre = "Nuevo Producto" };
            var mockRepo = new Mock<IProductRepository>();

            var service = new ProductService(mockRepo.Object);

            // Act
            await service.CreateProductAsync(productoDto);

            // Assert
            mockRepo.Verify(r => r.AddAsync(It.IsAny<ProductDto>()), Times.Once);
        }
        
    }
}
