﻿using Microsoft.EntityFrameworkCore;
using ProductosWebAPI.Domain.Entities;
using ProductosWebAPI.Domain.Interfaces;
using ProductosWebAPI.Infrastructure.Persistence.Contexts;

namespace ProductosWebAPI.Infrastructure.Repositories
{
    public class UsuarioRepository(AppDbContext appDbContext) : IUsuarioRepository
    {
        private readonly AppDbContext _context = appDbContext;  
        public async Task<UsuarioDto?> ObtenerPorUsernameAsync(string username)
        {
            var usuario = await _context.Usuarios
                .Where(u => u.Username == username)
                .Select(u => new UsuarioDto
                {
                    Id = u.Id,
                    Username = u.Username,
                    Password = u.Password,
                    Rol = u.Rol
                })
                .FirstOrDefaultAsync();

            return usuario;
        }
    }
}
