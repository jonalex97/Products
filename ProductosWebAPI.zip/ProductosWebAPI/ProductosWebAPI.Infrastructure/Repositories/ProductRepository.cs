﻿using Microsoft.EntityFrameworkCore;
using ProductosWebAPI.Domain.Entities;
using ProductosWebAPI.Domain.Interfaces;
using ProductosWebAPI.Infrastructure.Persistence.Contexts;
using ProductosWebAPI.Infrastructure.Persistence.Entities;

namespace ProductosWebAPI.Infrastructure.Repositories
{
    public class ProductRepository(AppDbContext appDbContext) : IProductRepository
    {
        private readonly AppDbContext _appDbContext = appDbContext;
        public async Task<IEnumerable<ProductDto>> GetAllAsync()
        {
            IEnumerable<ProductDto> products = new List<ProductDto>();

            products = await _appDbContext.Productos
                .Select(p => new ProductDto
                {
                    Id = p.Id,
                    Nombre = p.Nombre,
                    Precio = p.Precio,
                    Stock = p.Stock,
                    Estado = p.Estado,
                    Descripcion = p.Descripcion
                })
                .Where(p => p.Estado == true).ToListAsync();

            return products;
        }

        public async Task<ProductDto?> GetByIdAsync(Guid id)
        {
            return await _appDbContext.Productos
                .Where(p => p.Id == id)
                .Select(p => new ProductDto
                {
                    Id = p.Id,
                    Nombre = p.Nombre,
                    Precio = p.Precio,
                    Stock = p.Stock,
                    Estado = p.Estado,
                    Descripcion = p.Descripcion
                }).FirstOrDefaultAsync();
        }

        public async Task<bool> UpdateAsync(ProductDto product)
        {
            try
            {
                var productSet = _appDbContext.Productos.FirstOrDefault(p => p.Id == product.Id);
                var antiguo = productSet;
                if (productSet != null)
                {
                    productSet.Nombre = product.Nombre;
                    productSet.Precio = product.Precio;
                    productSet.Stock = product.Stock;
                    productSet.Descripcion = product.Descripcion;
                    _appDbContext.Productos.Update(productSet);
                    await _appDbContext.SaveChangesAsync();
                    SetHistorialProductAsync(productSet, antiguo, null).Wait();
                }
                else
                {
                    throw new KeyNotFoundException("Product not found");
                }
            }
            catch (Exception ex)
            {
                // Log the exception (not implemented here)
                return false;
            }
            return true;
        }

        public async Task<Guid> AddAsync(ProductDto product)
        {
            var newProduct = new Producto
            {
                Nombre = product.Nombre,
                Precio = product.Precio,
                Stock = product.Stock,
                Estado = product.Estado,
                Descripcion = product.Descripcion
            };
            _appDbContext.Productos.Add(newProduct);
            await _appDbContext.SaveChangesAsync();

            SetHistorialProductAsync(newProduct, null, null).Wait();
            return newProduct.Id;
        }

        public async Task<bool> DeleteAsync(Guid id)
        {
            try
            {
                var productSet = _appDbContext.Productos.FirstOrDefault(p => p.Id == id);
                var antiguo = productSet;
                if (productSet != null)
                {
                    productSet.Estado = false;
                    _appDbContext.Productos.Update(productSet);
                    await _appDbContext.SaveChangesAsync();

                    SetHistorialProductAsync(productSet, antiguo, null).Wait();
                }
                else
                {
                    throw new KeyNotFoundException("Product not found");
                }
            }
            catch (Exception ex)
            {
                // Log the exception (not implemented here)
                return false;
            }
            return true;
        }
        public async Task SetHistorialProductAsync(Producto nuevo, Producto anterior = null, string usuario = "Sistema")
        {
            var historial = new List<ProductoHistorial>();

            if (anterior == null)
            {
                // Registro de creación
                historial.Add(new ProductoHistorial
                {
                    ProductoId = nuevo.Id,
                    CampoModificado = "Creación",
                    ValorAnterior = null,
                    ValorNuevo = $"Nombre: {nuevo.Nombre}, Precio: {nuevo.Precio}",
                    UsuarioModificador = usuario
                });
            }
            else
            {
                // Comparar campo por campo
                if (nuevo.Nombre != anterior.Nombre)
                    historial.Add(CrearHistorial(nuevo.Id, "Nombre", anterior.Nombre, nuevo.Nombre, usuario));

                if (nuevo.Descripcion != anterior.Descripcion)
                    historial.Add(CrearHistorial(nuevo.Id, "Descripcion", anterior.Descripcion, nuevo.Descripcion, usuario));

                if (nuevo.Precio != anterior.Precio)
                    historial.Add(CrearHistorial(nuevo.Id, "Precio", anterior.Precio.ToString(), nuevo.Precio.ToString(), usuario));

                if (nuevo.Stock != anterior.Stock)
                    historial.Add(CrearHistorial(nuevo.Id, "Stock", anterior.Stock.ToString(), nuevo.Stock.ToString(), usuario));

                if (nuevo.Estado != anterior.Estado)
                    historial.Add(CrearHistorial(nuevo.Id, "Estado", anterior.Estado.ToString(), nuevo.Estado.ToString(), usuario));
            }

            if (historial.Any())
            {
                await _appDbContext.ProductoHistorials.AddRangeAsync(historial);
            }
        }

        private ProductoHistorial CrearHistorial(Guid productoId, string campo, string? anterior, string? nuevo, string usuario)
        {
            return new ProductoHistorial
            {
                ProductoId = productoId,
                CampoModificado = campo,
                ValorAnterior = anterior,
                ValorNuevo = nuevo,
                UsuarioModificador = usuario,
                FechaCambio = DateTime.UtcNow
            };
        }

    }
}
