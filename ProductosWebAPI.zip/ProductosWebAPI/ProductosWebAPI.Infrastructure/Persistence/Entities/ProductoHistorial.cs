﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ProductosWebAPI.Infrastructure.Persistence.Entities;

[Table("ProductoHistorial")]
public partial class ProductoHistorial
{
    [Key]
    public Guid Id { get; set; }

    public Guid ProductoId { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime FechaCambio { get; set; }

    [StringLength(100)]
    public string CampoModificado { get; set; } = null!;

    [StringLength(255)]
    public string? ValorAnterior { get; set; }

    [StringLength(255)]
    public string? ValorNuevo { get; set; }

    [StringLength(100)]
    public string UsuarioModificador { get; set; } = null!;

    [ForeignKey("ProductoId")]
    [InverseProperty("ProductoHistorials")]
    public virtual Producto Producto { get; set; } = null!;
}
