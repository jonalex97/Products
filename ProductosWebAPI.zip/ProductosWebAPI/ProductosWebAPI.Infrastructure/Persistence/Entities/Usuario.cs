﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ProductosWebAPI.Infrastructure.Persistence.Entities;

[Index("Username", Name = "UQ__Usuarios__536C85E4F0B93D64", IsUnique = true)]
public partial class Usuario
{
    [Key]
    public Guid Id { get; set; }

    [StringLength(100)]
    public string Username { get; set; } = null!;

    [StringLength(100)]
    public string Password { get; set; } = null!;

    [StringLength(50)]
    public string Rol { get; set; } = null!;
}
